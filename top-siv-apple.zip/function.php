<?php
$db = new DB();

function notification($msg,$type){
	$upper = strtoupper($type);
	return '
		<div class="alert alert-'.$type.' alert-dismissible fade show" role="alert">
		  <strong>'.$upper.'!</strong> '.$msg.'
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		  </button>
		</div>
	';
}

function redirect($url){
	ob_start();
	header('location:'.$url);
}

function clean($data){
	$data = trim($data);
	$data = stripslashes($data);
	return $data;
}

function if_exist($user,$pass)
{
  global $db;
	$stmt = $db->single("SELECT * FROM admin WHERE username = '{$user}' AND password = '{$pass}' LIMIT 1 ");
	$count = $db->rowcount();
	return($count > 0) ? true:false;
}

function login($user,$pass)
{
  global $db;
	if(if_exist($user,$pass)){
		$stmt = $db->single("SELECT * FROM admin WHERE username = '{$user}' AND password = '{$pass}' LIMIT 1 ");
		$count = $db->rowcount();
		if($count == 1){
			$id = $stmt->id;
			$username = $stmt->username;

			$_SESSION['sess_id'] = $id;
			$_SESSION['sess_username'] = $username;
			redirect('home.php');
		}
	}
}

function is_connected(){
	$connected = @fsockopen("www.google.com",80);
	if($connected){
		$is_conn = true;
		fclose($connected);
	}else{
		$is_conn = false;
	}

	return $is_conn;
}

function curl_get_contents($url){
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_HEADER,0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_URL,$url);

	$data = curl_exec($ch);
	curl_close($ch);

	return $data;
}

// Send Message to Parent Phone
function sendmessage($message,$phone,$sch,$parentname,$childname,$username,$password){

	
		$replace = array('_PARENT_' ,'_CHILD_');
		$replace_ = array( strtoupper($parentname) , strtoupper($childname) );
		$sms = str_replace($replace, $replace_, $message) ;

		$url = "http://www.peaksms.org/com_sms/smsapi.php?username=".$username."&password=".$password."&sender=".$sch."&recipient=".$phone."&message=".$sms;

		$url = str_replace(" ", "%20", $url);
		$result = curl_get_contents($url);

		return ($result === 'Success')? true: false;

}

