<?php
require('init.php');
include 'template/header.php';
$sms = $db->single("SELECT * FROM message  ");
$id = $sms->id;
if(isset($_POST['update'])){
  $arrival = clean($_POST['arrival']);
  $departure = clean($_POST['departure']);
  $sender = clean($_POST['sender']);
  $api_username = clean($_POST['api_username']);
  $api_password = clean($_POST['api_password']);

    $data = array(
      'arrival' => $arrival,
      'departure' => $departure,
      'Sender' => $sender,
      'api_username' => $api_username,
      'api_password' => $api_password
    );
    if($db->update('message',$data,$id)){
      $success = notification('Updated Successfully','success');
    }else{
      $error = notification('Error updating sms settings','danger');
    }

}
?>

<div class="container">
  <div class="row mt-5">
    <div class="col-md-12 col-lg-12">
        <h3 class="page-header pb-3">
          <span class="fa fa-envelope"></span> SMS SETTINGS
          <a href="home.php" class="btn btn-md btn-dark float-right"><i class="fa fa-home"></i> Home</a>
        </h3>
    </div>
  </div>
    <div class="row mt-2">
      <div class="col-md-6 col-lg-6">
        <?php if(!empty($error)){ echo $error; header('refresh: 2'); } ?>
        <?php if(!empty($success)){ echo $success; header('refresh: 2'); } ?>
        <form method="post">
           <div class="form-group">
            <label>Sender</label>
            <textarea name="sender" maxlength="11" class="form-control"><?php echo (!empty($sms->Sender))? trim($sms->Sender): " ";?></textarea>
            <span class="form-text text-muted">Max. length is 11</span>
          </div>
          <div class="form-group">
            <label>Edit Arrival Message</label>
            <textarea name="arrival" class="form-control"><?php echo (!empty($sms->arrival))? trim($sms->arrival): " ";?></textarea>
            <span class="form-text text-muted">Place "_PARENT_" anywhere you want Parent's Name to appear and "_CHILD_" where you want Child's Name to appear in the message. </span>
          </div>
          <div class="form-group">
            <label>Edit Departure Message</label>
            <textarea name="departure" class="form-control"><?php echo (!empty($sms->arrival))? trim($sms->departure): " ";?></textarea>
             <span class="form-text text-muted">Place "_PARENT_" anywhere you want Parent's Name to appear and "_CHILD_" where you want Child's Name to appear in the message. </span>
          </div>

          <div class="row">
            <div class="form-group col-md-6">
              <label>API Username:</label>
              <input type="text" name="api_username" class="form-control" value="<?php echo (!empty($sms->api_username))? trim($sms->api_username): " ";?>">
            </div>
            <div class="form-group col-md-6">
              <label>API Password:</label>
              <input type="password" name="api_password" class="form-control" value="<?php echo (!empty($sms->api_password))? trim($sms->api_password): " ";?>">
            </div>
          </div>

          <button class="btn btn-md btn-warning" name="update" type="submit">Update</button>
        </form>
      </div>
  </div>
</div>


<?php include 'template/footer.php'; ?>
