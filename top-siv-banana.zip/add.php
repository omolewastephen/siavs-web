<?php
require('init.php');
include 'template/header.php';

if (isset($_POST['submitbtn'])) {
  $surname = clean($_POST['surname']);
  $other_name = clean($_POST['other_name']);
  $class = clean($_POST['class']);
  $gender = clean($_POST['gender']);
  $cardnum = clean($_POST['cardnum']);
  $phone = clean($_POST['phone']);
  $parent = clean($_POST['parent']);
  $address = clean($_POST['address']);
  $sch_fees_status = clean($_POST['sch_fees_status']);
  $date_reg = date('Y-m-d');

  if(!empty($_FILES['stdimg']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/student/', $imgType, 5, 'mb');
		list($status, $studentPic) = $imageUpload->uploadSingleFile('stdimg');
	}
	if(!empty($_FILES['p1']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p1) = $imageUpload->uploadSingleFile('p1');
	}
	if(!empty($_FILES['p2']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p2) = $imageUpload->uploadSingleFile('p2');
	}
	if(!empty($_FILES['p3']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p3) = $imageUpload->uploadSingleFile('p3');
	}
	if(!empty($_FILES['p4']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p4) = $imageUpload->uploadSingleFile('p4');
	}
  if(!empty($_FILES['p5']['name'])){
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p5) = $imageUpload->uploadSingleFile('p5');
	}

  $data = array(
    'surname' => $surname,
    'other_name' => $other_name,
    'cardnum' => $cardnum,
    'gender' => $gender,
    'class' => $class,
    'sch_fees_status' => $sch_fees_status,
    'std_img' => $studentPic,
    'phone' => $phone,
    'address' => $address,
    'parent' => $parent,
    'parentOne_img' => $p1,
    'parentTwo_img' => $p2,
    'parentThree_img' => $p3,
    'parentFour_img' => $p4,
    'parentFive_img' => $p5,
    'date_reg' => $date_reg
  );

  if( $db->insert('students',$data) ){
    $success = notification('Student added successfully','success');
  }else{
    $error = notification('Error adding student data','danger');
  }

}
?>

<div class="container">
  <div class="row mt-3 mb-3">
    <div class="col-md-12 col-lg-12">
        <h3 class="page-header pb-3">
          <span class="fa fa-users"></span> ADD NEW STUDENT
          <a href="std.php" class="btn btn-md btn-warning float-right"><i class="fa fa-list"></i> Registered Students</a>
          <a href="home.php" class="btn btn-md btn-dark float-right"><i class="fa fa-home"></i> Home</a>
        </h3>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-md-12 col-lg-12">
      <?php if(!empty($error)){ echo $error; } ?>
      <?php if(!empty($success)){ echo $success; } ?>
      <form method="post" enctype="multipart/form-data">
        <div class="row">
          <div class="form-group col-md-4 col-lg-4">
            <label>Surname:</label>
            <input type="text" class="form-control" name="surname" required/>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>Other Names:</label>
            <input type="text" class="form-control" name="other_name" required/>
          </div>
          <div class="form-group col-lg-4 col-md-4">
            <label>Card Number:</label>
            <input type="text" class="form-control" name="cardnum" required/>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-lg-4 col-md-4">
            <label>Parents:</label>
            <input type="text" class="form-control" name="parent" placeholder="Mr/Mrs John Doe" required/>
          </div>
          <div class="form-group col-lg-4 col-md-4">
            <label>Home Address:</label>
            <input type="text" class="form-control" name="address" required/>
          </div>
          <div class="form-group col-lg-4 col-md-4">
            <label>Phone Number:</label>
            <input type="text" class="form-control" placeholder="+234XXXXXXXXXXXX" name="phone" required/>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-4 col-lg-4">
            <label>Gender:</label>
            <select class="form-control" name="gender" required>
              <option value="">--Choose--</option>
              <option value="M">Male</option>
              <option value="F">Female</option>
            </select>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>Class:</label>
            <input type="text" class="form-control" name="class" required/>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>School Fees Status:</label>
            <select class="form-control" name="sch_fees_status" required>
              <option value="">--Choose--</option>
              <option value="Not Paid">Not Paid</option>
              <option value="Paid">Paid</option>
              <option value="Incomplete">Incomplete</option>
            </select>
          </div>
         </div>

         <div class="form-group">
           <label>Student Image:</label>
           <input type="file" class="form-control" name="stdimg" required/>
         </div>

         <div class="row mt-5 mb-1">
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="images/no.png" id="preview" width="70" height="70" class="img-fluid" />
             </div>
             <label>Parent Photo</label>
              <input type="file" class="form-control" id="p1" name="p1" required/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="images/no.png" id="preview2" width="70" height="70" class="img-fluid" />
             </div>
             <label>Parent Photo</label>
              <input type="file" class="form-control" id="p2" name="p2" required/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="images/no.png" id="preview3" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 1</label>
              <input type="file" class="form-control" id="p3" name="p3" required/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="images/no.png" id="preview4" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 2</label>
              <input type="file" class="form-control" id="p4" name="p4" required/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="images/no.png" id="preview5" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 3</label>
              <input type="file" class="form-control" id="p5" name="p5" required/>
           </div>
         </div>

         <button type="submit" name="submitbtn" class="btn btn-md btn-warning">Submit</button>
      </form>
    </div>
  </div>
</div>

<?php include 'template/footer.php'; ?>
