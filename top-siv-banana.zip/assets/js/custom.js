function readURL(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}
function readURL2(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview2").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}
function readURL3(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview3").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}
function readURL4(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview4").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}

function readURL5(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview5").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}
function readURL6(input)
{
	if(input.files && input.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			$("#preview6").attr('src',e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}

$("#p1").change(function(){
	readURL(this);
});
$("#p2").change(function(){
	readURL2(this);
});
$("#p3").change(function(){
	readURL3(this);
});
$("#p4").change(function(){
	readURL4(this);
});
$("#p5").change(function(){
	readURL5(this);
});
$("#p6").change(function(){
	readURL6(this);
});
