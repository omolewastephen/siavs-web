<?php
require('init.php');
include 'template/header.php';
$success = $error = "";
if(isset($_GET['id']) AND !empty($_GET['id'])){
  $id = (int)$_GET['id'];
  $student = $db->single("SELECT * FROM students WHERE id = '{$id}' ");
}
if (isset($_POST['updatebtn'])) {
  $surname = clean($_POST['surname']);
  $other_name = clean($_POST['other_name']);
  $class = clean($_POST['class']);
  $gender = clean($_POST['gender']);
  $cardnum = clean($_POST['cardnum']);
  $sch_fees_status = clean($_POST['sch_fees_status']);
  $phone = clean($_POST['phone']);
  $parent = clean($_POST['parent']);
  $address = clean($_POST['address']);

  if(!empty($_FILES['stdimg']['name'])){
    if(file_exists(getcwd()."/".$student->std_img)){
      unlink(getcwd()."/".$student->std_img);
    }
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/student/', $imgType, 5, 'mb');
		list($status, $studentPic) = $imageUpload->uploadSingleFile('stdimg');
	}else{
    $studentPic = $student->std_img;
  }
	if(!empty($_FILES['p1']['name'])){
    if(file_exists(getcwd()."/".$student->parentOne_img)){
      unlink(getcwd()."/".$student->parentOne_img);
    }
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p1) = $imageUpload->uploadSingleFile('p1');
	}else{
    $p1 = $student->parentOne_img;
  }
	if(!empty($_FILES['p2']['name'])){
    if(file_exists(getcwd()."/".$student->parentTwo_img)){
      unlink(getcwd()."/".$student->parentTwo_img);
    }
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p2) = $imageUpload->uploadSingleFile('p2');
	}else{
    $p2 = $student->parentTwo_img;
  }
	if(!empty($_FILES['p3']['name'])){
    if(file_exists(getcwd()."/".$student->parentThree_img)){
      unlink(getcwd()."/".$student->parentThree_img);
    }

		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p3) = $imageUpload->uploadSingleFile('p3');
	}else{
    $p3 = $student->parentThree_img;
  }
	if(!empty($_FILES['p4']['name'])){
    if(file_exists(getcwd()."/".$student->parentFour_img)){
      unlink(getcwd()."/".$student->parentFour_img);
    }
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p4) = $imageUpload->uploadSingleFile('p4');
	}else{
    $p4 = $student->parentFour_img;
  }
  if(!empty($_FILES['p6']['name'])){
    if(file_exists(getcwd()."/".$student->parentFive_img)){
      unlink(getcwd()."/".$student->parentFive_img);
    }
		$imgType = array('image/jpg', 'image/png', 'image/jpeg', 'image/bmp');
		$imageUpload = new FileUpload('uploads/parent/', $imgType, 5, 'mb');
		list($status, $p6) = $imageUpload->uploadSingleFile('p6');
	}else{
    $p6 = $student->parentFive_img;
  }

  $data = array(
    'surname' => $surname,
    'other_name' => $other_name,
    'cardnum' => $cardnum,
    'gender' => $gender,
    'class' => $class,
    'sch_fees_status' => $sch_fees_status,
    'std_img' => $studentPic,
    'phone' => $phone,
    'address' => $address,
    'parent' => $parent,
    'parentOne_img' => $p1,
    'parentTwo_img' => $p2,
    'parentThree_img' => $p3,
    'parentFour_img' => $p4,
    'parentFive_img' => $p6,
  );

  if( $db->update('students',$data,$id) ){
    $success = notification('Student information updated successfully','success');
  }else{
    print_r($db->update('students',$data,$id));
    $error = notification('Error updating student data. Try Again','danger');
  }

}
?>

<div class="container">
  <div class="row mt-3 mb-3">
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
        <h3 class="page-header pb-3">
          <span class="fa fa-users"></span> EDIT STUDENT DATA
          <a href="std.php" class="btn btn-md btn-warning float-right"><i class="fa fa-list"></i> Registered Students</a>
          <a href="home.php" class="btn btn-md btn-dark float-right"><i class="fa fa-home"></i> Home</a>
        </h3>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-md-8 col-lg-8">
      <?php if(!empty($error)){ echo $error; header('refresh: 2'); } ?>
      <?php if(!empty($success)){ echo $success; header('refresh: 2'); } ?>
      <form method="post" enctype="multipart/form-data">
        <div class="row">
          <div class="form-group col-md-4 col-lg-4">
            <label>Surname:</label>
            <input type="text" class="form-control" value="<?php echo $student->surname; ?>" name="surname" required/>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>Other Names:</label>
            <input type="text" class="form-control" value="<?php echo $student->other_name; ?>" name="other_name" required/>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>Card Number:</label>
            <input type="text" value="<?php echo $student->cardnum; ?>" class="form-control" name="cardnum" required/>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-lg-4 col-md-4">
            <label>Parents:</label>
            <input type="text" class="form-control" value="<?php echo $student->parent; ?>" name="parent" placeholder="Mr & Mrs John Doe" required/>
          </div>
          <div class="form-group col-lg-4 col-md-4">
            <label>Home Address:</label>
            <input type="text" class="form-control" value="<?php echo $student->address; ?>" name="address" required/>
          </div>
          <div class="form-group col-lg-4 col-md-4">
            <label>Phone Number:</label>
            <input type="text" class="form-control" value="<?php echo $student->phone; ?>" placeholder="+234XXXXXXXXXXXX" name="phone" required/>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-4 col-lg-4">
            <label>Gender:</label>
            <select class="form-control" name="gender" required>
              <option value="<?php echo $student->gender; ?>"> <?php echo ($student->gender == 'M')? 'Male': 'Female'; ?> </option>
              <option value="">--Choose--</option>
              <option value="M">Male</option>
              <option value="F">Female</option>
            </select>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>Class:</label>
            <input type="text" value="<?php echo $student->class; ?>" class="form-control" name="class" required/>
          </div>
          <div class="form-group col-md-4 col-lg-4">
            <label>School Fees Status:</label>
            <select class="form-control" name="sch_fees_status" required>
              <option value="<?php echo $student->sch_fees_status; ?>"><?php echo $student->sch_fees_status; ?></option>
              <option value="">--Choose--</option>
              <option value="Not Paid">Not Paid</option>
              <option value="Paid">Paid</option>
              <option value="Incomplete">Incomplete</option>
            </select>
          </div>
         </div>

         <div class="row">
           <div class="form-group col-md-10 col-lg-10">
             <label>Student Image:</label>
             <input type="file" class="form-control" id="p5" name="stdimg"/>
           </div>
           <div class="col-md-2 col-lg-2">
             <img src="<?php echo $student->std_img ?>" id="preview5" width="100" height="100"/>
           </div>
         </div>

         <div class="row mt-5 mb-1">
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="<?php echo $student->parentOne_img ?>" id="preview" width="70" height="70" class="img-fluid" />
             </div>
             <label>Parent Photo</label>
              <input type="file" class="form-control" id="p1" name="p1"/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="<?php echo $student->parentTwo_img ?>" id="preview2" width="70" height="70" class="img-fluid" />
             </div>
             <label>Parent Photo</label>
              <input type="file" class="form-control" id="p2" name="p2"/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="<?php echo $student->parentThree_img ?>" id="preview3" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 1</label>
              <input type="file" class="form-control" id="p3" name="p3"/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="<?php echo $student->parentFour_img ?>" id="preview4" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 2</label>
              <input type="file" class="form-control" id="p4" name="p4"/>
           </div>
           <div class="form-group col text-center">
             <div class="avatar">
               <img src="<?php echo $student->parentFive_img ?>" id="preview6" width="70" height="70" class="img-fluid" />
             </div>
             <label>Guardian 3</label>
              <input type="file" class="form-control" id="p6" name="p6"/>
           </div>
         </div>

         <button type="submit" name="updatebtn" class="btn btn-md btn-warning">Submit</button>
      </form>
    </div>
  </div>
</div>

<?php include 'template/footer.php'; ?>
